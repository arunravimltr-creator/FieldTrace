# FieldTrace — PhD Field Mapping App

Live GPS path + green collection points + yellow object-origin lines.
Designed for multi-year field data collection. All research data stays on the device until you export.

## What this package contains

```
FieldTrace/
  web/                 ← use this immediately in a mobile browser
  android/             ← Android Studio project → APK
  docs/                ← field protocol
  README.md
  README_ML.md
```

## Honest limit

A ready-to-install `.apk` cannot be compiled in this environment (no Android SDK / Gradle cache, ~2 GB RAM).  
The Android project is complete. On a laptop with Android Studio you can produce the APK in a few minutes.  
Until then, the `web/` app works on the phone browser with the same features.

---

## Use today (no APK)

On the phone, files must be served from `http://localhost` or `https://` for GPS to work. `file://` often blocks location in Chrome.

1. Copy the `web` folder to the phone or to a laptop.
2. From the `web` folder run:
   ```bash
   python3 -m http.server 8080
   ```
3. On the same phone, open `http://PHONE_LAN_IP:8080`  
   or, if Python runs on the phone (Termux): `http://127.0.0.1:8080`
4. Chrome menu → **Add to Home screen**.
5. Allow **Precise location**.

Maps and place-search need internet (OpenStreetMap + Nominatim). GPS itself is on-device.

---

## Build the APK (Android Studio)

1. Install [Android Studio](https://developer.android.com/studio).
2. File → Open → select the `android` folder.
3. Let Gradle sync.
4. Connect the phone with USB debugging, or use an emulator.
5. Build → Generate Signed Bundle / APK → APK.
6. For fieldwork testing you can also press the green Run button; Android Studio will install a debug APK.

First install: allow Location (Precise), Camera, Notifications, and **unrestricted battery** for FieldTrace.

If Android Studio asks for a missing launcher mipmap, the project already uses `@drawable/ic_logo`.

---

## How to use in the field

| Control | Action |
|---|---|
| **START** | Begins a trip. Every accepted GPS fix is stored and drawn as a **blue line**. |
| **STOP** | Ends the trip. Data remains saved. |
| **ADD** | Drops a **green point** at your current GPS, opens the form. |
| Form | Person name, notes, object, photo, origin place. |
| Origin search | Type the place they named → tap a result. A **yellow line** is drawn from the green point to that place. |
| Pin origin on map | If the name is vague, tap the exact spot. |
| Green point tap | Shows that stop’s details and photo only. |
| **☰** | Opens **all** green-point records at once. |
| **FINAL MAP** | Fits the whole archive: paths + green points + yellow origin lines. |
| **EXPORT** | JSON backup, GeoJSON, GPX, CSV, A1 PDF report. |
| **PLAYBACK** | Animates the walked path. Screen-record this for a video. |

GPS points closer than ~4 m or with accuracy worse than ~45 m are ignored so the line does not shake.

---

## Data that is stored (on device)

- Trip sessions
- Track points (lat, lng, accuracy, time)
- Collection stops (person, notes, object, origin text + coordinates, photo)

Nothing is uploaded to a server by this app.

### Backup rule (3–4 year project)

Export **Full JSON backup** after every field day, and copy it off the phone (laptop + cloud).  
Also export GeoJSON for QGIS. A single phone is not an archive.

---

## Theatre-size / exhibition output

1. Export **GeoJSON**.
2. Open in QGIS (free).
3. Style: blue line = track, green point = collection, yellow line = origin.
4. Project → New Print Layout → page size A0 / A1 / custom (e.g. 3840×2160 px).
5. Export PDF or TIFF at 300 dpi.

The in-app **Large PDF report** is an A1 landscape HTML table + photos. Use the browser Print dialog → Save as PDF → paper size A1/A0, background graphics ON.

Video: FINAL MAP or PLAYBACK + phone/computer screen recorder at the highest resolution available.

---

## Permissions / battery

- Precise location
- Camera (object photos)
- Notification (foreground service)
- Disable battery optimization for FieldTrace
- Keep the app in recent-apps; do not swipe it away while tracking
- Android may still throttle GPS if the screen is off for a long time. For critical walks keep the screen on (the activity is flagged keep-screen-on).

---

## Suggested next additions (when you send the extra fields)

- Edit / delete a saved green point
- Extra custom fields you define
- Audio note
- Multi-user merge of JSON backups
- Offline map tiles for a study region

Send the exact form fields you want inside each green point and they can be added without changing the map logic.
