# FieldTrace — suggested field protocol

1. Full battery + power bank. Disable battery optimization for FieldTrace.
2. Open app outdoors. Wait until status shows a GPS accuracy (preferably under 15 m).
3. Press START before you begin walking.
4. Walk normally. Do not swipe the app away.
5. At each informant / collection:
   - Stand still 5–10 seconds.
   - Press ADD.
   - Fill person, notes, object.
   - Take the object photo immediately.
   - Search the stated origin place and tap the correct result, or pin it on the map.
   - Save.
6. Continue walking. Repeat.
7. STOP when the day’s walk ends.
8. FINAL MAP — visual check that the yellow lines and green points look right.
9. EXPORT JSON + GeoJSON before you sleep. Copy off the phone the same day.

Accuracy notes for the thesis methods chapter:
- Receiver: phone GNSS, high-accuracy mode.
- Track filter: ignore fixes with accuracy > 45 m; ignore moves < 4 m.
- Origin coordinates come from Nominatim geocoding of the informant’s stated place, or a manual map pin — not from a second GPS visit unless you later verify.
- State this distinction clearly in the dissertation: collection point = measured GNSS; origin point = reported location, geocoded.
