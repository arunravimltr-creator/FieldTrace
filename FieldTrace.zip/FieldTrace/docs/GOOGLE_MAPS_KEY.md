# Google Maps key — do this yourself. Do not share your Google password.

FieldTrace never logs into your Google account.
A Maps API key is a short code created in Google Cloud. Paste it only inside the app (Projects → Save map key). It stays on the phone.

## Create the key

1. Open https://console.cloud.google.com/
2. Create a project, e.g. `FieldTrace-PhD`.
3. Enable:
   - Maps JavaScript API
   - Geocoding API
4. Credentials → Create credentials → API key.
5. Restrict the key:
   - Application restriction: Android apps, package `com.phd.fieldtrace` + your SHA-1  
     and/or HTTP referrers if you also use the web copy.
   - API restriction: only the two APIs above.
6. In FieldTrace: Projects → paste key → Save map key.

Without a key the app still works on OpenStreetMap. Markings are always inside FieldTrace, not on your personal Google Maps account.
