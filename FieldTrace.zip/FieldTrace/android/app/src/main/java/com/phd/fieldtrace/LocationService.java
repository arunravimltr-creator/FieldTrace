package com.phd.fieldtrace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

public class LocationService extends Service implements LocationListener {
    public static final String CHANNEL = "fieldtrace_gps";
    public static final String ACTION_FIX = "com.phd.fieldtrace.FIX";
    private LocationManager lm;
    private Location last;
    private static final float MAX_ACC_M = 22f;
    private static final float MIN_MOVE_M = 3f;
    private static final float MAX_SPEED_MPS = 6.5f;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL,
                    getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription(getString(R.string.channel_desc));
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new NotificationCompat.Builder(this, CHANNEL)
                .setContentTitle("FieldTrace live")
                .setContentText("Tracking until PAUSE / SAVE DAY — calls and other apps are OK")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(17, n);
        startGps();
    }

    private void startGps() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return;
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (lm == null) return;
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, MIN_MOVE_M, this);
            }
        } catch (SecurityException ignored) {}
    }

    @Override
    public void onLocationChanged(@NonNull Location loc) {
        if (loc.hasAccuracy() && loc.getAccuracy() > MAX_ACC_M) return;
        if (last != null) {
            float d = loc.distanceTo(last);
            float minD = Math.max(MIN_MOVE_M, Math.min(8f, loc.getAccuracy() * 0.28f));
            if (d < minD) return;
            long dt = Math.max(500L, loc.getTime() - last.getTime());
            float speed = d / (dt / 1000f);
            if (speed > MAX_SPEED_MPS && d > 20f) return;
        }
        last = loc;
        Intent i = new Intent(ACTION_FIX);
        i.setPackage(getPackageName());
        i.putExtra("lat", loc.getLatitude());
        i.putExtra("lng", loc.getLongitude());
        i.putExtra("acc", loc.hasAccuracy() ? loc.getAccuracy() : 0f);
        i.putExtra("t", loc.getTime() > 0 ? loc.getTime() : System.currentTimeMillis());
        sendBroadcast(i);
        try {
            java.io.File f = new java.io.File(getFilesDir(), "pending_fixes.jsonl");
            java.io.FileWriter w = new java.io.FileWriter(f, true);
            w.write("{\"lat\":" + loc.getLatitude() + ",\"lng\":" + loc.getLongitude()
                    + ",\"acc\":" + (loc.hasAccuracy() ? loc.getAccuracy() : 0)
                    + ",\"t\":" + (loc.getTime() > 0 ? loc.getTime() : System.currentTimeMillis()) + "}\n");
            w.close();
        } catch (Exception ignored) {}
    }

    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override public void onProviderEnabled(@NonNull String provider) {}
    @Override public void onProviderDisabled(@NonNull String provider) {}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
