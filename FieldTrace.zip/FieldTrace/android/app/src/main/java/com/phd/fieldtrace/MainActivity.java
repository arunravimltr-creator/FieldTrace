package com.phd.fieldtrace;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private boolean sessionLive = false;
    private static final int REQ_PERM = 41;
    private static final int REQ_FILE = 42;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.webview);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, true);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = params.createIntent();
                try {
                    startActivityForResult(i, REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Cannot open camera/files", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new JsBridge(), "FieldTraceAndroid");
        requestNeededPermissions();
        IntentFilter filter = new IntentFilter(LocationService.ACTION_FIX);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(fixReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(fixReceiver, filter);
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
    }

    private final BroadcastReceiver fixReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (web == null || !sessionLive) return;
            double lat = intent.getDoubleExtra("lat", 0);
            double lng = intent.getDoubleExtra("lng", 0);
            float acc = intent.getFloatExtra("acc", 0);
            long t = intent.getLongExtra("t", System.currentTimeMillis());
            String js = "window.App&&App.onNativeFix({lat:" + lat + ",lng:" + lng + ",acc:" + acc + ",t:" + t + "})";
            web.evaluateJavascript(js, null);
        }
    };

    public class JsBridge {
        @JavascriptInterface
        public void saveSnapshot(String json) {
            try {
                java.io.File f = new java.io.File(getFilesDir(), "fieldtrace-autosave.json");
                java.io.FileWriter w = new java.io.FileWriter(f, false);
                w.write(json == null ? "{}" : json);
                w.close();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void setTracking(boolean on) {
            runOnUiThread(() -> {
                sessionLive = on;
                if (on) {
                    startTracker();
                    askBatteryExemption();
                    askBackgroundLocation();
                } else stopTracker();
            });
        }
    }

    private void requestNeededPermissions() {
        java.util.ArrayList<String> need = new java.util.ArrayList<>();
        String[] base = new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CAMERA
        };
        for (String p : base) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            ActivityCompat.requestPermissions(this, need.toArray(new String[0]), REQ_PERM);
        }
    }

    private void startTracker() {
        Intent i = new Intent(this, LocationService.class);
        ContextCompat.startForegroundService(this, i);
    }

    private void askBackgroundLocation() {
        if (Build.VERSION.SDK_INT >= 29 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, REQ_PERM + 2);
        }
    }

    private void stopTracker() {
        stopService(new Intent(this, LocationService.class));
    }

    private void askBatteryExemption() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] grant) {
        super.onRequestPermissionsResult(code, perms, grant);
        /* Location is used only after RESUME/START. No background tracking on launch. */
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if (fileCallback != null) fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        flushPendingFixes();
    }

    private void flushPendingFixes() {
        if (web == null || !sessionLive) return;
        try {
            java.io.File f = new java.io.File(getFilesDir(), "pending_fixes.jsonl");
            if (!f.exists()) return;
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(f));
            String line;
            while ((line = r.readLine()) != null) {
                final String js = "window.App&&App.onNativeFix(" + line + ")";
                web.evaluateJavascript(js, null);
            }
            r.close();
            // keep last 0 — file cleared after inject
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(fixReceiver); } catch (Exception ignored) {}
        if (!sessionLive) stopTracker();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
