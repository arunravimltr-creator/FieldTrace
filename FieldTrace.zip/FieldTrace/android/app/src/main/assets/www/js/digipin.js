/* Official DIGIPIN encode/decode — India Post / IIT-H / NRSC-ISRO public algorithm.
   Bounds cover India incl. J&K, Ladakh, Aksai Chin, Arunachal, maritime box.
   Outside 2.5–38.5N, 63.5–99.5E the function returns null (e.g. Gulf trial). */
const DIGIPIN_GRID = [
  ['F', 'C', '9', '8'],
  ['J', '3', '2', '7'],
  ['K', '4', '5', '6'],
  ['L', 'M', 'P', 'T']
];
const DIGIPIN_BOUNDS = { minLat: 2.5, maxLat: 38.5, minLon: 63.5, maxLon: 99.5 };

const DIGIPIN = {
  inIndia(lat, lon) {
    return lat >= DIGIPIN_BOUNDS.minLat && lat <= DIGIPIN_BOUNDS.maxLat &&
      lon >= DIGIPIN_BOUNDS.minLon && lon <= DIGIPIN_BOUNDS.maxLon;
  },
  encode(lat, lon) {
    if (!this.inIndia(lat, lon)) return null;
    let minLat = DIGIPIN_BOUNDS.minLat, maxLat = DIGIPIN_BOUNDS.maxLat;
    let minLon = DIGIPIN_BOUNDS.minLon, maxLon = DIGIPIN_BOUNDS.maxLon;
    let pin = '';
    for (let level = 1; level <= 10; level++) {
      const latDiv = (maxLat - minLat) / 4;
      const lonDiv = (maxLon - minLon) / 4;
      let row = 3 - Math.floor((lat - minLat) / latDiv);
      let col = Math.floor((lon - minLon) / lonDiv);
      row = Math.max(0, Math.min(row, 3));
      col = Math.max(0, Math.min(col, 3));
      pin += DIGIPIN_GRID[row][col];
      maxLat = minLat + latDiv * (4 - row);
      minLat = minLat + latDiv * (3 - row);
      minLon = minLon + lonDiv * col;
      maxLon = minLon + lonDiv;
    }
    return pin;
  },
  format(pin) {
    if (!pin || pin.length !== 10) return pin || '';
    return pin.slice(0, 3) + '-' + pin.slice(3, 6) + '-' + pin.slice(6);
  },
  of(lat, lon) {
    const raw = this.encode(lat, lon);
    return raw ? this.format(raw) : null;
  }
};
window.DIGIPIN = DIGIPIN;
