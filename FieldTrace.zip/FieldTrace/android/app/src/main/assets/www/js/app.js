const App = {
  tracking: false,
  trip: null,
  project: null,
  lastFix: null,
  follow: true,
  labelsOn: false,
  pendingPhoto: null,
  originPick: null,
  geocodeTimer: null,
  googleKey: '',

  async boot() {
    await FTDB.init();
    await this.migrateLegacy();
    this.googleKey = (await FTDB.getMeta('googleMapsKey')) || '';
    this.bind();
    await this.ensureProject();
    await this.initMapEngine();
    await this.redraw();
    this.toast('RESUME മുതൽ PAUSE വരെ ട്രാക്ക്. കോളും മറ്റ് ആപ്പും OK.');
    this.tryLocate();
    if ('serviceWorker' in navigator) {
      try { await navigator.serviceWorker.register('sw.js'); } catch (e) { /* optional */ }
    }
  },

  nativeTrack(on) {
    try {
      if (window.FieldTraceAndroid && FieldTraceAndroid.setTracking) FieldTraceAndroid.setTracking(!!on);
    } catch (e) { /* browser */ }
  },

  async onNativeFix(pt) {
    if (!this.tracking || !pt || pt.lat == null) return;
    await this.onGps({
      lat: pt.lat,
      lng: pt.lng,
      acc: pt.acc || 0,
      t: pt.t || Date.now()
    });
  },

  async migrateLegacy() {
    let projects = await FTDB.all('projects');
    const points = await FTDB.all('points');
    const stops = await FTDB.all('stops');
    const trips = await FTDB.all('trips');
    if (!projects.length && (points.length || stops.length || trips.length)) {
      const p = {
        id: 'proj_legacy',
        name: 'PhD main map',
        kind: 'main',
        createdAt: Date.now(),
        lastOpenedAt: Date.now()
      };
      await FTDB.put('projects', p);
      for (const t of trips) { if (!t.projectId) { t.projectId = p.id; await FTDB.put('trips', t); } }
      for (const x of points) { if (!x.projectId) { x.projectId = p.id; await FTDB.put('points', x); } }
      for (const x of stops) { if (!x.projectId) { x.projectId = p.id; await FTDB.put('stops', x); } }
      await FTDB.setMeta('currentProjectId', p.id);
    }
  },

  async ensureProject() {
    let projects = await FTDB.all('projects');
    let id = await FTDB.getMeta('currentProjectId');
    this.project = id ? await FTDB.get('projects', id) : null;
    if (!this.project) {
      if (!projects.length) {
        this.project = await this.createProject('PhD main map', 'main');
      } else {
        projects.sort((a, b) => (b.lastOpenedAt || 0) - (a.lastOpenedAt || 0));
        this.project = projects[0];
        await FTDB.setMeta('currentProjectId', this.project.id);
      }
    }
    this.project.lastOpenedAt = Date.now();
    await FTDB.put('projects', this.project);
    this.renderProjectName();
  },

  async createProject(name, kind) {
    const p = {
      id: FTDB.uid('proj'),
      name: name || ('Project ' + new Date().toLocaleDateString()),
      kind: kind || 'trial',
      createdAt: Date.now(),
      lastOpenedAt: Date.now()
    };
    await FTDB.put('projects', p);
    await FTDB.setMeta('currentProjectId', p.id);
    return p;
  },

  renderProjectName() {
    const el = document.getElementById('projectName');
    if (el && this.project) {
      el.textContent = this.project.name + (this.project.kind === 'trial' ? ' (trial)' : '');
    }
  },

  async initMapEngine() {
    let ok = false;
    if (this.googleKey) {
      try { ok = await window.loadGoogleMaps(this.googleKey); } catch (e) {
        this.toast('Google Maps key failed. Using OpenStreetMap. Check the key.');
      }
    }
    await FTMap.init('map', ok ? this.googleKey : '');
    const engine = document.getElementById('mapEngine');
    if (engine) engine.textContent = FTMap.engine === 'google' ? 'Google Map' : 'OSM map';
  },

  bind() {
    document.getElementById('btnStart').onclick = () => this.toggleTrack();
    document.getElementById('btnAdd').onclick = () => this.openAdd();
    document.getElementById('btnFinal').onclick = () => this.finalMap();
    document.getElementById('btnLabels').onclick = () => this.toggleLabels();
    document.getElementById('btnExport').onclick = () => this.openExport();
    document.getElementById('btnLocate').onclick = () => this.tryLocate(true);
    document.getElementById('btnProjects').onclick = () => this.openProjects();
    document.getElementById('btnSaveDay').onclick = () => this.saveDay();
    document.getElementById('btnCloseAdd').onclick = () => this.closeSheet('sheetAdd');
    document.getElementById('btnCloseExport').onclick = () => this.closeSheet('sheetExport');
    document.getElementById('btnCloseDetails').onclick = () => this.closeSheet('sheetDetails');
    document.getElementById('btnCloseAll').onclick = () => this.closeSheet('sheetAll');
    document.getElementById('btnCloseProjects').onclick = () => this.closeSheet('sheetProjects');
    document.getElementById('btnSaveStop').onclick = () => this.saveStop();
    document.getElementById('photoInput').onchange = (e) => this.onPhoto(e);
    document.getElementById('originSearch').oninput = (e) => this.searchOrigin(e.target.value);
    document.getElementById('btnPickOrigin').onclick = () => this.enableOriginPick();
    document.getElementById('backdrop').onclick = () => this.closeAllSheets();
    document.getElementById('btnJson').onclick = () => FTExport.exportJson();
    document.getElementById('btnGeo').onclick = () => FTExport.exportGeoJSON(this.project && this.project.id);
    document.getElementById('btnCsv').onclick = () => FTExport.exportCsv(this.project && this.project.id);
    document.getElementById('btnGpx').onclick = () => FTExport.exportGpx(this.project && this.project.id);
    document.getElementById('btnPdf').onclick = () => FTExport.exportPdfLarge(this.project && this.project.id);
    document.getElementById('btnPlay').onclick = () => this.playback();
    document.getElementById('btnNewMain').onclick = () => this.newProjectFlow('main');
    document.getElementById('btnNewTrial').onclick = () => this.newProjectFlow('trial');
    document.getElementById('btnSaveKey').onclick = () => this.saveGoogleKey();
    GPS.on(pt => this.onGps(pt));
  },

  async openProjects() {
    const list = document.getElementById('projectList');
    const projects = (await FTDB.all('projects')).sort((a, b) => (b.lastOpenedAt || 0) - (a.lastOpenedAt || 0));
    list.innerHTML = projects.map(p => `
      <button type="button" class="project-item ${this.project && p.id === this.project.id ? 'active' : ''}" data-id="${p.id}">
        <b>${this.esc(p.name)}</b>
        <span>${p.kind === 'trial' ? 'Trial' : 'Main'} · ${new Date(p.createdAt).toLocaleDateString()}</span>
      </button>
    `).join('') || '<p>No projects yet.</p>';
    list.querySelectorAll('button[data-id]').forEach(b => {
      b.onclick = () => this.switchProject(b.dataset.id);
    });
    document.getElementById('googleKeyInput').value = this.googleKey || '';
    this.openSheet('sheetProjects');
  },

  async newProjectFlow(kind) {
    const name = (document.getElementById('newProjectName').value || '').trim()
      || (kind === 'trial' ? 'Trial ' + new Date().toLocaleString() : 'PhD map ' + new Date().toLocaleDateString());
    if (this.tracking) await this.saveDay(true);
    this.project = await this.createProject(name, kind);
    this.trip = null;
    this.renderProjectName();
    await this.redraw();
    this.closeSheet('sheetProjects');
    this.toast((kind === 'trial' ? 'Trial project' : 'New main project') + ' ready. Empty map. Old projects are untouched.');
  },

  async switchProject(id) {
    if (this.tracking) await this.saveDay(true);
    this.project = await FTDB.get('projects', id);
    this.project.lastOpenedAt = Date.now();
    await FTDB.put('projects', this.project);
    await FTDB.setMeta('currentProjectId', id);
    this.trip = null;
    this.renderProjectName();
    await this.redraw();
    this.closeSheet('sheetProjects');
    this.toast('Resumed project: ' + this.project.name);
    this.finalMap();
  },

  async saveGoogleKey() {
    const key = (document.getElementById('googleKeyInput').value || '').trim();
    this.googleKey = key;
    await FTDB.setMeta('googleMapsKey', key);
    await this.initMapEngine();
    await this.redraw();
    this.toast(key ? 'Google Maps key saved on this phone only.' : 'Key cleared. Using OpenStreetMap.');
  },

  async tryLocate(follow) {
    try {
      const p = await GPS.once();
      this.lastFix = p;
      FTMap.setYou(p.lat, p.lng, p.acc);
      if (follow || this.follow) FTMap.follow(p.lat, p.lng);
      this.setStatus(this.tracking ? 'LIVE' : 'Ready to resume', this.tracking);
    } catch (e) {
      this.setStatus('GPS denied', false);
      this.toast('Location permission needed. Enable GPS / precise location.');
    }
  },

  async saveDay(silent) {
    this.tracking = false;
    GPS.stop();
    this.nativeTrack(false);
    if (this.trip) {
      this.trip.endedAt = Date.now();
      this.trip.status = 'saved';
      this.trip.endedLabel = new Date().toLocaleString();
      await FTDB.put('trips', this.trip);
    }
    document.getElementById('btnStart').textContent = 'RESUME';
    document.getElementById('btnStart').classList.remove('stop');
    this.setStatus('Day saved', false);
    if (!silent) this.toast('Paused. GPS disconnected. Same map kept. RESUME when you want.');
  },

  async toggleTrack() {
    if (this.tracking) {
      await this.saveDay();
      return;
    }
    if (!this.project) await this.ensureProject();
    this.trip = {
      id: FTDB.uid('trip'),
      projectId: this.project.id,
      name: 'Day ' + new Date().toLocaleString(),
      startedAt: Date.now(),
      endedAt: null,
      status: 'live'
    };
    await FTDB.put('trips', this.trip);
    this.tracking = true;
    GPS.lastAccepted = null;
    FTMap.startLiveSegment();
    GPS.start();
    this.nativeTrack(true);
    document.getElementById('btnStart').textContent = 'PAUSE';
    document.getElementById('btnStart').classList.add('stop');
    this.setStatus('LIVE', true);
    this.toast('Live. Calls / WhatsApp OK. PAUSE or SAVE DAY stops tracking.');
    this.tryLocate(true);
  },

  async onGps(pt) {
    if (pt.error) {
      this.setStatus('GPS error', false);
      return;
    }
    this.lastFix = pt;
    if (!pt.skipped) {
      FTMap.setYou(pt.lat, pt.lng, pt.acc);
      if (this.tracking && this.trip && this.project) {
        await FTDB.put('points', {
          id: FTDB.uid('pt'),
          projectId: this.project.id,
          tripId: this.trip.id,
          lat: pt.lat, lng: pt.lng, acc: pt.acc, t: pt.t
        });
        FTMap.appendTrack(pt.lat, pt.lng);
        if (this.follow) FTMap.follow(pt.lat, pt.lng);
      }
      this.setStatus(this.tracking ? ('LIVE ±' + Math.round(pt.acc || 0) + 'm') : ('Ready ±' + Math.round(pt.acc || 0) + 'm'), this.tracking);
    } else if (this.lastFix) {
      FTMap.setYou(this.lastFix.lat, this.lastFix.lng, this.lastFix.acc);
    }
  },

  async projectPoints() {
    const all = await FTDB.all('points');
    return all.filter(p => !this.project || p.projectId === this.project.id || !p.projectId);
  },
  async projectStops() {
    const all = await FTDB.all('stops');
    return all.filter(p => !this.project || p.projectId === this.project.id || !p.projectId);
  },
  async projectTrips() {
    const all = await FTDB.all('trips');
    return all.filter(p => !this.project || p.projectId === this.project.id || !p.projectId);
  },

  segmentsFromPoints(points) {
    const byTrip = {};
    points.sort((a, b) => a.t - b.t).forEach(p => {
      (byTrip[p.tripId || 'x'] ||= []).push(p);
    });
    return Object.values(byTrip);
  },

  async openAdd() {
    let here = this.lastFix;
    try { here = await GPS.once(); this.lastFix = here; } catch (e) { /* last */ }
    if (!here) {
      this.toast('No GPS fix yet. Wait for location, then press ADD.');
      return;
    }
    this.pendingPhoto = null;
    this.originPick = null;
    document.getElementById('personName').value = '';
    document.getElementById('infoText').value = '';
    document.getElementById('objectName').value = '';
    document.getElementById('originSearch').value = '';
    document.getElementById('originChosen').textContent = '';
    document.getElementById('photoPreview').src = '';
    document.getElementById('photoPreview').classList.add('hidden');
    document.getElementById('searchResults').innerHTML = '';
    document.getElementById('addGps').textContent =
      here.lat.toFixed(6) + ', ' + here.lng.toFixed(6) + '  (±' + Math.round(here.acc || 0) + 'm)';
    this.openSheet('sheetAdd');
  },

  onPhoto(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    this.pendingPhoto = f;
    const img = document.getElementById('photoPreview');
    img.src = URL.createObjectURL(f);
    img.classList.remove('hidden');
  },

  searchOrigin(q) {
    clearTimeout(this.geocodeTimer);
    const box = document.getElementById('searchResults');
    if (!q || q.trim().length < 3) { box.innerHTML = ''; return; }
    this.geocodeTimer = setTimeout(() => this.geocode(q.trim(), box), 500);
  },

  async geocode(q, box) {
    try {
      let items = [];
      if (this.googleKey) {
        const url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' + encodeURIComponent(q) + '&key=' + encodeURIComponent(this.googleKey);
        const res = await fetch(url);
        const data = await res.json();
        if (data.status === 'OK') {
          items = data.results.slice(0, 6).map(r => ({
            lat: r.geometry.location.lat,
            lng: r.geometry.location.lng,
            name: r.formatted_address
          }));
        }
      }
      if (!items.length) {
        const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&q=' + encodeURIComponent(q);
        const res = await fetch(url, { headers: { 'Accept': 'application/json', 'Accept-Language': 'en,ml' } });
        const data = await res.json();
        items = data.map(r => ({ lat: parseFloat(r.lat), lng: parseFloat(r.lon), name: r.display_name }));
      }
      box.innerHTML = items.map(item =>
        `<button type="button" data-lat="${item.lat}" data-lng="${item.lng}">${this.esc(item.name)}</button>`
      ).join('') || '<button type="button">Place not found — pin on map</button>';
      box.querySelectorAll('button[data-lat]').forEach(b => {
        b.onclick = () => {
          this.originPick = { lat: parseFloat(b.dataset.lat), lng: parseFloat(b.dataset.lng), text: b.textContent };
          document.getElementById('originChosen').textContent = 'Origin: ' + b.textContent;
          box.innerHTML = '';
        };
      });
    } catch (err) {
      box.innerHTML = '<button type="button">Search failed — check internet</button>';
    }
  },

  enableOriginPick() {
    this.toast('Tap the map to mark where the object came from.');
    this.closeSheet('sheetAdd');
    FTMap.onceClick((ll) => {
      this.originPick = {
        lat: ll.lat, lng: ll.lng,
        text: document.getElementById('originSearch').value ||
          ('Map pin ' + ll.lat.toFixed(5) + ', ' + ll.lng.toFixed(5))
      };
      document.getElementById('originChosen').textContent =
        'Origin pinned: ' + this.originPick.lat.toFixed(5) + ', ' + this.originPick.lng.toFixed(5);
      this.openSheet('sheetAdd');
      this.toast('Origin pinned. Save the collection point.');
    });
  },

  async saveStop() {
    const here = this.lastFix;
    if (!here) { this.toast('No GPS fix.'); return; }
    if (!this.project) await this.ensureProject();
    if (!this.trip) {
      this.trip = {
        id: FTDB.uid('trip'),
        projectId: this.project.id,
        name: 'Ad-hoc ' + new Date().toLocaleString(),
        startedAt: Date.now(),
        status: 'open'
      };
      await FTDB.put('trips', this.trip);
    }
    let photoId = null;
    if (this.pendingPhoto) {
      photoId = FTDB.uid('ph');
      await FTDB.put('photos', { id: photoId, mime: this.pendingPhoto.type || 'image/jpeg', blob: this.pendingPhoto });
    }
    const stop = {
      id: FTDB.uid('st'),
      projectId: this.project.id,
      tripId: this.trip.id,
      lat: here.lat, lng: here.lng, acc: here.acc, t: Date.now(),
      personName: document.getElementById('personName').value.trim(),
      info: document.getElementById('infoText').value.trim(),
      objectName: document.getElementById('objectName').value.trim(),
      originText: (this.originPick && this.originPick.text) || document.getElementById('originSearch').value.trim(),
      originLat: this.originPick ? this.originPick.lat : null,
      originLng: this.originPick ? this.originPick.lng : null,
      photoId
    };
    await FTDB.put('stops', stop);
    this.closeSheet('sheetAdd');
    await this.redraw();
    this.toast('Green point saved on this project map.');
  },

  async redraw() {
    FTMap.clearOverlays();
    const points = await this.projectPoints();
    const stops = await this.projectStops();
    FTMap.setTracks(this.segmentsFromPoints(points));
    stops.forEach(s => FTMap.addStop(s, st => this.showStop(st)));
    this.updateCounts(points.length, stops.length);
    this.renderProjectName();
  },

  async showStop(st) {
    let photoHtml = '';
    if (st.photoId) {
      const ph = await FTDB.get('photos', st.photoId);
      if (ph) photoHtml = `<img src="${URL.createObjectURL(ph.blob)}" alt="object"/>`;
    }
    document.getElementById('detailBody').innerHTML = `
      <div class="detail-card">
        <h3>${this.esc(st.personName || 'Collection point')}</h3>
        <p><b>Object:</b> ${this.esc(st.objectName || '—')}</p>
        <p><b>Origin:</b> ${this.esc(st.originText || '—')}</p>
        <p><b>Notes:</b> ${this.esc(st.info || '—')}</p>
        <p><b>Time:</b> ${new Date(st.t).toLocaleString()}</p>
        <p><b>GPS:</b> ${st.lat.toFixed(6)}, ${st.lng.toFixed(6)}</p>
        ${st.originLat != null ? `<p><b>Origin GPS:</b> ${st.originLat.toFixed(6)}, ${st.originLng.toFixed(6)}</p>` : ''}
        ${photoHtml}
      </div>`;
    this.openSheet('sheetDetails');
    FTMap.follow(st.lat, st.lng);
  },

  async toggleLabels() {
    this.labelsOn = !this.labelsOn;
    document.getElementById('btnLabels').classList.toggle('yellow', this.labelsOn);
    if (!this.labelsOn) { this.closeSheet('sheetAll'); return; }
    const stops = (await this.projectStops()).sort((a, b) => a.t - b.t);
    const parts = [];
    for (const st of stops) {
      let img = '';
      if (st.photoId) {
        const ph = await FTDB.get('photos', st.photoId);
        if (ph) img = `<img src="${URL.createObjectURL(ph.blob)}" alt=""/>`;
      }
      parts.push(`<div class="detail-card">
        <h3>${this.esc(st.personName || 'Stop')} — ${this.esc(st.objectName || '')}</h3>
        <p>${this.esc(st.info || '')}</p>
        <p>Origin: ${this.esc(st.originText || '—')}</p>
        <p>${new Date(st.t).toLocaleString()}</p>${img}
      </div>`);
    }
    document.getElementById('allBody').innerHTML = parts.join('') || '<p>No collection points yet.</p>';
    this.openSheet('sheetAll');
  },

  async finalMap() {
    const points = await this.projectPoints();
    const stops = await this.projectStops();
    await this.redraw();
    FTMap.fitAll(points, stops);
    this.toast('Full project map — all days together.');
  },

  openExport() { this.openSheet('sheetExport'); },

  async playback() {
    const points = (await this.projectPoints()).sort((a, b) => a.t - b.t);
    if (points.length < 2) { this.toast('Need more track points to play back.'); return; }
    this.closeAllSheets();
    FTMap.setTracks([]);
    FTMap.startLiveSegment();
    let i = 0;
    this.toast('Playback of this project. Screen-record for video.');
    const step = () => {
      if (i >= points.length) { this.toast('Playback finished.'); this.redraw(); return; }
      const p = points[i++];
      FTMap.appendTrack(p.lat, p.lng);
      FTMap.setYou(p.lat, p.lng, p.acc);
      if (i % 4 === 0) FTMap.follow(p.lat, p.lng);
      setTimeout(step, 25);
    };
    step();
  },

  openSheet(id) {
    document.getElementById('backdrop').classList.add('show');
    document.getElementById(id).classList.add('open');
  },
  closeSheet(id) {
    document.getElementById(id).classList.remove('open');
    if (!document.querySelector('.sheet.open')) document.getElementById('backdrop').classList.remove('show');
  },
  closeAllSheets() {
    document.querySelectorAll('.sheet.open').forEach(s => s.classList.remove('open'));
    document.getElementById('backdrop').classList.remove('show');
  },
  setStatus(text, live) {
    document.getElementById('statusText').textContent = text;
    document.getElementById('statusDot').classList.toggle('live', !!live);
  },
  updateCounts(pts, stops) {
    document.getElementById('counts').textContent = pts + ' pts · ' + stops + ' stops';
  },
  toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(this._tt);
    this._tt = setTimeout(() => t.classList.remove('show'), 3400);
  },
  esc(s) {
    return String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }
};

window.addEventListener('DOMContentLoaded', () => App.boot());
window.App = App;
