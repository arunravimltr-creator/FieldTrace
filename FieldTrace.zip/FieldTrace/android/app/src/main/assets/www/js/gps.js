/* Walking-field GPS: drop jitter, teleports, and standing-still noise */
const GPS = {
  watchId: null,
  lastAccepted: null,
  minMeters: 3,
  maxAccuracy: 22,
  maxSpeed: 6.5,
  listeners: [],

  on(fn) { this.listeners.push(fn); },
  emit(pt) { this.listeners.forEach(fn => fn(pt)); },

  haversine(a, b) {
    const R = 6371000;
    const toR = x => x * Math.PI / 180;
    const dLat = toR(b.lat - a.lat);
    const dLng = toR(b.lng - a.lng);
    const s = Math.sin(dLat / 2) ** 2 +
      Math.cos(toR(a.lat)) * Math.cos(toR(b.lat)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
  },

  accept(raw) {
    const pt = {
      lat: raw.lat,
      lng: raw.lng,
      acc: raw.acc || 0,
      alt: raw.alt,
      t: raw.t || Date.now()
    };
    if (pt.acc && pt.acc > this.maxAccuracy) {
      return { ...pt, skipped: 'accuracy' };
    }
    if (this.lastAccepted) {
      const d = this.haversine(this.lastAccepted, pt);
      const dt = Math.max(0.5, (pt.t - this.lastAccepted.t) / 1000);
      const speed = d / dt;
      const minD = Math.max(this.minMeters, Math.min(8, (pt.acc || 8) * 0.28));
      if (d < minD) return { ...pt, skipped: 'jitter', dist: d };
      if (speed > this.maxSpeed && d > 20) {
        return { ...pt, skipped: 'teleport', dist: d, speed };
      }
    }
    this.lastAccepted = pt;
    return pt;
  },

  start() {
    if (!navigator.geolocation) throw new Error('Geolocation not available');
    if (this.watchId != null) return;
    this.watchId = navigator.geolocation.watchPosition(
      pos => {
        this.emit(this.accept({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          acc: pos.coords.accuracy,
          alt: pos.coords.altitude,
          t: pos.timestamp || Date.now()
        }));
      },
      err => this.emit({ error: err.message || String(err), code: err.code }),
      { enableHighAccuracy: true, maximumAge: 0, timeout: 25000 }
    );
  },

  stop() {
    if (this.watchId != null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
  },

  once() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('no geo'));
      navigator.geolocation.getCurrentPosition(
        p => resolve({
          lat: p.coords.latitude,
          lng: p.coords.longitude,
          acc: p.coords.accuracy,
          t: p.timestamp || Date.now()
        }),
        reject,
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 2000 }
      );
    });
  }
};

window.GPS = GPS;
