/* High-accuracy GPS with jitter filter — suitable for walking fieldwork */
const GPS = {
  watchId: null,
  lastAccepted: null,
  minMeters: 4,
  maxAccuracy: 45,
  listeners: [],

  on(fn) { this.listeners.push(fn); },
  emit(pt) { this.listeners.forEach(fn => fn(pt)); },

  haversine(a, b) {
    const R = 6371000;
    const toR = x => x * Math.PI / 180;
    const dLat = toR(b.lat - a.lat);
    const dLng = toR(b.lng - a.lng);
    const s = Math.sin(dLat/2)**2 + Math.cos(toR(a.lat))*Math.cos(toR(b.lat))*Math.sin(dLng/2)**2;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
  },

  start() {
    if (!navigator.geolocation) throw new Error('Geolocation not available');
    if (this.watchId != null) return;
    this.watchId = navigator.geolocation.watchPosition(
      pos => {
        const pt = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          acc: pos.coords.accuracy,
          alt: pos.coords.altitude,
          t: pos.timestamp || Date.now()
        };
        if (pt.acc && pt.acc > this.maxAccuracy) {
          this.emit({ ...pt, skipped: 'accuracy' });
          return;
        }
        if (this.lastAccepted) {
          const d = this.haversine(this.lastAccepted, pt);
          if (d < this.minMeters) {
            this.emit({ ...pt, skipped: 'jitter', dist: d });
            return;
          }
        }
        this.lastAccepted = pt;
        this.emit(pt);
      },
      err => this.emit({ error: err.message || String(err), code: err.code }),
      { enableHighAccuracy: true, maximumAge: 800, timeout: 20000 }
    );
  },

  stop() {
    if (this.watchId != null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
  },

  once() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('no geo'));
      navigator.geolocation.getCurrentPosition(
        p => resolve({
          lat: p.coords.latitude,
          lng: p.coords.longitude,
          acc: p.coords.accuracy,
          t: p.timestamp || Date.now()
        }),
        reject,
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 2000 }
      );
    });
  }
};

window.GPS = GPS;
