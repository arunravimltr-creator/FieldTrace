self.addEventListener('install', (e) => {
  e.waitUntil(caches.open('fieldtrace-v1').then(c => c.addAll([
    './', './index.html', './css/app.css', './js/db.js', './js/gps.js', './js/map.js', './js/export.js', './js/app.js', './manifest.json'
  ]).catch(() => {})));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (url.hostname.includes('tile.openstreetmap.org') || url.hostname.includes('nominatim')) return;
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
