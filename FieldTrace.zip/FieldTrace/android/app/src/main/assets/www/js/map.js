/* Unified map: Google Maps JS when API key exists, otherwise OpenStreetMap + Leaflet */
const FTMap = {
  engine: 'leaflet',
  map: null,
  gmap: null,
  trackLayer: null,
  stopLayer: null,
  originLayer: null,
  youMarker: null,
  accCircle: null,
  trackLine: null,
  gPolylines: [],
  gActive: null,
  gStops: [],
  gOrigins: [],
  gYou: null,
  gAcc: null,
  stopMarkers: new Map(),
  pendingMapClick: null,

  async init(elId, googleKey) {
    this.destroy();
    if (googleKey && window.google && google.maps) {
      this.engine = 'google';
      return this.initGoogle(elId);
    }
    this.engine = 'leaflet';
    return this.initLeaflet(elId);
  },

  destroy() {
    if (this.map) {
      try { this.map.remove(); } catch (e) {}
      this.map = null;
    }
    this.gmap = null;
    this.gPolylines = [];
    this.gActive = null;
    this.gStops = [];
    this.gOrigins = [];
    this.gYou = null;
    this.gAcc = null;
    this.youMarker = null;
    this.accCircle = null;
    this.trackLine = null;
    this.stopMarkers = new Map();
  },

  initLeaflet(elId) {
    this.map = L.map(elId, { zoomControl: true, worldCopyJump: true, maxZoom: 19 }).setView([10.1632, 76.6413], 7);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(this.map);
    this.trackLayer = L.layerGroup().addTo(this.map);
    this.originLayer = L.layerGroup().addTo(this.map);
    this.stopLayer = L.layerGroup().addTo(this.map);
    this.trackLine = L.polyline([], { color: '#3b82f6', weight: 4, opacity: 0.9, lineJoin: 'round' }).addTo(this.trackLayer);
    this.map.on('click', (e) => {
      if (this.pendingMapClick) {
        const fn = this.pendingMapClick;
        this.pendingMapClick = null;
        fn({ lat: e.latlng.lat, lng: e.latlng.lng });
      }
    });
    return this.map;
  },

  initGoogle(elId) {
    const el = document.getElementById(elId);
    this.gmap = new google.maps.Map(el, {
      center: { lat: 10.1632, lng: 76.6413 },
      zoom: 7,
      mapTypeId: 'roadmap',
      streetViewControl: false,
      fullscreenControl: false,
      mapTypeControl: true,
      clickableIcons: false
    });
    this.gActive = new google.maps.Polyline({
      path: [], geodesic: true, strokeColor: '#3b82f6',
      strokeOpacity: 0.95, strokeWeight: 4, map: this.gmap
    });
    this.gmap.addListener('click', (e) => {
      if (this.pendingMapClick) {
        const fn = this.pendingMapClick;
        this.pendingMapClick = null;
        fn({ lat: e.latLng.lat(), lng: e.latLng.lng() });
      }
    });
    return this.gmap;
  },

  onceClick(fn) { this.pendingMapClick = fn; },

  setYou(lat, lng, acc) {
    if (this.engine === 'google' && this.gmap) {
      const pos = { lat, lng };
      if (!this.gYou) {
        this.gYou = new google.maps.Marker({
          position: pos, map: this.gmap, title: 'You',
          icon: {
            path: google.maps.SymbolPath.CIRCLE, scale: 8,
            fillColor: '#38bdf8', fillOpacity: 1, strokeColor: '#0ea5e9', strokeWeight: 2
          }
        });
      } else this.gYou.setPosition(pos);
      if (acc && acc < 80) {
        if (!this.gAcc) {
          this.gAcc = new google.maps.Circle({
            map: this.gmap, center: pos, radius: acc,
            strokeColor: '#38bdf8', strokeWeight: 1, fillColor: '#38bdf8', fillOpacity: 0.08
          });
        } else {
          this.gAcc.setCenter(pos);
          this.gAcc.setRadius(acc);
        }
      }
      return;
    }
    if (!this.map) return;
    const here = [lat, lng];
    if (!this.youMarker) {
      this.youMarker = L.circleMarker(here, {
        radius: 8, color: '#0ea5e9', weight: 2, fillColor: '#38bdf8', fillOpacity: 1
      }).addTo(this.map);
    } else this.youMarker.setLatLng(here);
    if (acc && acc < 80) {
      if (!this.accCircle) {
        this.accCircle = L.circle(here, { radius: acc, color: '#38bdf8', weight: 1, fillOpacity: 0.06 }).addTo(this.map);
      } else this.accCircle.setLatLng(here).setRadius(acc);
    }
  },

  follow(lat, lng) {
    if (this.engine === 'google' && this.gmap) {
      const z = Math.max(this.gmap.getZoom() || 16, 16);
      this.gmap.setCenter({ lat, lng });
      this.gmap.setZoom(z);
      return;
    }
    if (!this.map) return;
    this.map.setView([lat, lng], Math.max(this.map.getZoom(), 16), { animate: true });
  },

  setTracks(segments) {
    if (this.engine === 'google' && this.gmap) {
      this.gPolylines.forEach(p => p.setMap(null));
      this.gPolylines = [];
      (segments || []).forEach(seg => {
        if (!seg.length) return;
        this.gPolylines.push(new google.maps.Polyline({
          path: seg.map(p => ({ lat: p.lat, lng: p.lng })),
          geodesic: true, strokeColor: '#3b82f6', strokeOpacity: 0.9, strokeWeight: 4, map: this.gmap
        }));
      });
      if (this.gActive) this.gActive.setPath([]);
      return;
    }
    if (!this.trackLayer) return;
    this.trackLayer.clearLayers();
    (segments || []).forEach(seg => {
      if (seg.length) {
        L.polyline(seg.map(p => [p.lat, p.lng]), {
          color: '#3b82f6', weight: 4, opacity: 0.9, lineJoin: 'round'
        }).addTo(this.trackLayer);
      }
    });
    this.trackLine = L.polyline([], { color: '#3b82f6', weight: 4, opacity: 0.95 }).addTo(this.trackLayer);
  },

  startLiveSegment() {
    if (this.engine === 'google' && this.gmap) {
      this.gActive = new google.maps.Polyline({
        path: [], geodesic: true, strokeColor: '#3b82f6',
        strokeOpacity: 1, strokeWeight: 5, map: this.gmap
      });
      return;
    }
    this.trackLine = L.polyline([], { color: '#3b82f6', weight: 5, opacity: 1 }).addTo(this.trackLayer);
  },

  appendTrack(lat, lng) {
    if (this.engine === 'google' && this.gActive) {
      this.gActive.getPath().push(new google.maps.LatLng(lat, lng));
      return;
    }
    if (this.trackLine) this.trackLine.addLatLng([lat, lng]);
  },

  addStop(stop, onClick) {
    const click = () => onClick && onClick(stop);
    if (this.engine === 'google' && this.gmap) {
      const m = new google.maps.Marker({
        position: { lat: stop.lat, lng: stop.lng }, map: this.gmap,
        title: stop.personName || stop.objectName || 'Stop',
        icon: {
          path: google.maps.SymbolPath.CIRCLE, scale: 9,
          fillColor: '#22c55e', fillOpacity: 1, strokeColor: '#052e16', strokeWeight: 2
        }
      });
      m.addListener('click', click);
      this.gStops.push(m);
      if (stop.originLat != null && stop.originLng != null) {
        this.gOrigins.push(new google.maps.Polyline({
          path: [{ lat: stop.lat, lng: stop.lng }, { lat: stop.originLat, lng: stop.originLng }],
          geodesic: true, strokeColor: '#f5c518', strokeOpacity: 0.95, strokeWeight: 3, map: this.gmap
        }));
        this.gOrigins.push(new google.maps.Marker({
          position: { lat: stop.originLat, lng: stop.originLng }, map: this.gmap,
          title: stop.originText || 'Origin',
          icon: {
            path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW, scale: 5,
            fillColor: '#f5c518', fillOpacity: 1, strokeColor: '#3b2d00', strokeWeight: 1
          }
        }));
      }
      return;
    }
    const icon = L.divIcon({
      className: '', html: '<div class="marker-green" style="width:16px;height:16px"></div>',
      iconSize: [16, 16], iconAnchor: [8, 8]
    });
    const m = L.marker([stop.lat, stop.lng], { icon, title: stop.personName || stop.objectName || 'Stop' }).addTo(this.stopLayer);
    m.on('click', click);
    this.stopMarkers.set(stop.id, m);
    if (stop.originLat != null && stop.originLng != null) {
      L.polyline([[stop.lat, stop.lng], [stop.originLat, stop.originLng]], {
        color: '#f5c518', weight: 3, opacity: 0.95, dashArray: '6 8'
      }).addTo(this.originLayer);
      const oIcon = L.divIcon({
        className: '', html: '<div class="marker-origin" style="width:12px;height:12px"></div>',
        iconSize: [12, 12], iconAnchor: [6, 6]
      });
      L.marker([stop.originLat, stop.originLng], { icon: oIcon, title: stop.originText || 'Origin' }).addTo(this.originLayer);
    }
  },

  clearOverlays() {
    if (this.engine === 'google') {
      this.gPolylines.forEach(p => p.setMap(null));
      this.gPolylines = [];
      this.gStops.forEach(p => p.setMap(null));
      this.gStops = [];
      this.gOrigins.forEach(p => p.setMap(null));
      this.gOrigins = [];
      if (this.gActive) this.gActive.setPath([]);
      return;
    }
    if (this.stopLayer) this.stopLayer.clearLayers();
    if (this.originLayer) this.originLayer.clearLayers();
    if (this.trackLayer) this.trackLayer.clearLayers();
    this.stopMarkers.clear();
    if (this.map) {
      this.trackLine = L.polyline([], { color: '#3b82f6', weight: 4, opacity: 0.9 }).addTo(this.trackLayer);
    }
  },

  fitAll(points, stops) {
    const pts = [];
    (points || []).forEach(p => pts.push({ lat: p.lat, lng: p.lng }));
    (stops || []).forEach(s => {
      pts.push({ lat: s.lat, lng: s.lng });
      if (s.originLat != null) pts.push({ lat: s.originLat, lng: s.originLng });
    });
    if (!pts.length) return;
    if (this.engine === 'google' && this.gmap) {
      const b = new google.maps.LatLngBounds();
      pts.forEach(p => b.extend(p));
      this.gmap.fitBounds(b);
      return;
    }
    if (this.map) this.map.fitBounds(pts.map(p => [p.lat, p.lng]), { padding: [40, 40], maxZoom: 17 });
  }
};

window.FTMap = FTMap;

window.loadGoogleMaps = function (key) {
  return new Promise((resolve, reject) => {
    if (!key) return resolve(false);
    if (window.google && google.maps) return resolve(true);
    window.__gmapsReady = () => resolve(true);
    const s = document.createElement('script');
    s.id = 'gmaps-script';
    s.async = true;
    s.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent(key) + '&callback=__gmapsReady';
    s.onerror = () => reject(new Error('Google Maps script blocked — check API key'));
    document.head.appendChild(s);
  });
};
