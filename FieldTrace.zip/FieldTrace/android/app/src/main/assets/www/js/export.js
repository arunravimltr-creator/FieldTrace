const FTExport = {
  download(filename, blob) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  },

  async fullArchive() {
    const trips = await FTDB.all('trips');
    const points = await FTDB.all('points');
    const stops = await FTDB.all('stops');
    const photos = await FTDB.all('photos');
    const photoOut = [];
    for (const p of photos) {
      photoOut.push({
        id: p.id,
        mime: p.mime,
        dataUrl: await this.blobToDataUrl(p.blob)
      });
    }
    const projects = await FTDB.all('projects');
    return {
      app: 'FieldTrace',
      version: 2,
      exportedAt: new Date().toISOString(),
      projects, trips, points, stops, photos: photoOut
    };
  },

  async scoped(projectId) {
    const points = await FTDB.all('points');
    const stops = await FTDB.all('stops');
    const trips = await FTDB.all('trips');
    if (!projectId) return { points, stops, trips };
    return {
      points: points.filter(p => p.projectId === projectId || !p.projectId),
      stops: stops.filter(p => p.projectId === projectId || !p.projectId),
      trips: trips.filter(p => p.projectId === projectId || !p.projectId)
    };
  },

  blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = reject;
      r.readAsDataURL(blob);
    });
  },

  async exportJson() {
    const data = await this.fullArchive();
    this.download(
      'FieldTrace_backup_' + new Date().toISOString().slice(0,19).replace(/[:T]/g,'-') + '.json',
      new Blob([JSON.stringify(data)], { type: 'application/json' })
    );
  },

  async exportGeoJSON(projectId) {
    const { points, stops } = await this.scoped(projectId);
    const features = [];

    const byTrip = {};
    points.sort((a,b) => a.t - b.t).forEach(p => {
      (byTrip[p.tripId] ||= []).push([p.lng, p.lat]);
    });
    Object.entries(byTrip).forEach(([tripId, coords]) => {
      if (coords.length >= 2) {
        features.push({
          type: 'Feature',
          properties: { kind: 'track', tripId, color: '#3b82f6' },
          geometry: { type: 'LineString', coordinates: coords }
        });
      }
    });

    stops.forEach(s => {
      features.push({
        type: 'Feature',
        properties: {
          kind: 'collection',
          color: '#22c55e',
          personName: s.personName,
          info: s.info,
          objectName: s.objectName,
          originText: s.originText,
          time: new Date(s.t).toISOString()
        },
        geometry: { type: 'Point', coordinates: [s.lng, s.lat] }
      });
      if (s.originLat != null && s.originLng != null) {
        features.push({
          type: 'Feature',
          properties: { kind: 'origin-link', color: '#f5c518', objectName: s.objectName, originText: s.originText },
          geometry: { type: 'LineString', coordinates: [[s.lng, s.lat], [s.originLng, s.originLat]] }
        });
        features.push({
          type: 'Feature',
          properties: { kind: 'origin', color: '#f5c518', originText: s.originText },
          geometry: { type: 'Point', coordinates: [s.originLng, s.originLat] }
        });
      }
    });

    const gj = { type: 'FeatureCollection', name: 'FieldTrace', features };
    this.download('FieldTrace_map.geojson', new Blob([JSON.stringify(gj, null, 2)], { type: 'application/geo+json' }));
  },

  async exportCsv(projectId) {
    const { stops } = await this.scoped(projectId);
    const header = ['id','time','lat','lng','personName','info','objectName','originText','originLat','originLng'];
    const lines = [header.join(',')];
    const q = v => '"' + String(v ?? '').replace(/"/g,'""') + '"';
    stops.sort((a,b)=>a.t-b.t).forEach(s => {
      lines.push([s.id, new Date(s.t).toISOString(), s.lat, s.lng, q(s.personName), q(s.info), q(s.objectName), q(s.originText), s.originLat ?? '', s.originLng ?? ''].join(','));
    });
    this.download('FieldTrace_collections.csv', new Blob([lines.join('\n')], { type: 'text/csv' }));
  },

  async exportGpx(projectId) {
    const scoped = await this.scoped(projectId);
    const points = scoped.points.sort((a,b)=>a.t-b.t);
    const stops = scoped.stops;
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="FieldTrace" xmlns="http://www.topografix.com/GPX/1/1">
<trk><name>FieldTrace tracks</name><trkseg>
`;
    points.forEach(p => {
      xml += `<trkpt lat="${p.lat}" lon="${p.lng}"><time>${new Date(p.t).toISOString()}</time></trkpt>\n`;
    });
    xml += `</trkseg></trk>\n`;
    stops.forEach(s => {
      xml += `<wpt lat="${s.lat}" lon="${s.lng}"><name>${this.xml(s.personName || s.objectName || 'stop')}</name><desc>${this.xml((s.objectName||'') + ' | ' + (s.originText||'') + ' | ' + (s.info||''))}</desc></wpt>\n`;
    });
    xml += `</gpx>`;
    this.download('FieldTrace_track.gpx', new Blob([xml], { type: 'application/gpx+xml' }));
  },

  xml(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  },

  async exportPdfLarge(projectId) {
    /* High-resolution static map via OSM static composition is limited.
       We print a research-grade A1 HTML report the browser can Save as PDF. */
    const scoped = await this.scoped(projectId);
    const trips = scoped.trips;
    const stops = scoped.stops.sort((a,b)=>a.t-b.t);
    const points = scoped.points;
    const w = window.open('', '_blank');
    if (!w) throw new Error('Popup blocked — allow popups to export PDF');
    const rows = [];
    for (const s of stops) {
      let img = '';
      if (s.photoId) {
        const ph = await FTDB.get('photos', s.photoId);
        if (ph) {
          const url = await this.blobToDataUrl(ph.blob);
          img = `<img src="${url}" style="width:220px;height:160px;object-fit:cover;border-radius:8px"/>`;
        }
      }
      rows.push(`<tr>
        <td>${new Date(s.t).toLocaleString()}</td>
        <td>${s.lat.toFixed(6)}, ${s.lng.toFixed(6)}</td>
        <td>${this.esc(s.personName)}</td>
        <td>${this.esc(s.objectName)}</td>
        <td>${this.esc(s.originText)}</td>
        <td>${s.originLat != null ? s.originLat.toFixed(5)+', '+s.originLng.toFixed(5) : ''}</td>
        <td>${this.esc(s.info)}</td>
        <td>${img}</td>
      </tr>`);
    }
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>FieldTrace Final Map Report</title>
<style>
  @page { size: A1 landscape; margin: 18mm; }
  body { font-family: "Noto Sans", "Noto Sans Malayalam", sans-serif; color:#0b1220; }
  h1 { margin: 0 0 8px; }
  .meta { color:#334155; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th, td { border: 1px solid #cbd5e1; padding: 8px; vertical-align: top; }
  th { background: #0f172a; color: white; }
  .note { margin-top: 16px; font-size: 12px; color:#334155; }
</style></head><body>
<h1>FieldTrace — Final research map report</h1>
<div class="meta">Trips: ${trips.length} &nbsp;|&nbsp; Track points: ${points.length} &nbsp;|&nbsp; Collection stops: ${stops.length} &nbsp;|&nbsp; Exported: ${new Date().toLocaleString()}</div>
<p>Print this page with <b>Save as PDF</b>. Choose paper size <b>A1 / A0 / Custom large</b>, landscape, background graphics ON. For theatre screens also export GeoJSON and open in QGIS for wall-size print.</p>
<table><thead><tr>
<th>Time</th><th>Collection GPS</th><th>Person</th><th>Object</th><th>Origin place</th><th>Origin GPS</th><th>Notes</th><th>Photo</th>
</tr></thead><tbody>${rows.join('')}</tbody></table>
<div class="note">Blue line = researcher path. Green point = collection event. Yellow line = stated object origin. This report is generated locally on-device; no server copy is created by FieldTrace.</div>
</body></html>`);
    w.document.close();
  },

  esc(s) {
    return String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }
};

window.FTExport = FTExport;
