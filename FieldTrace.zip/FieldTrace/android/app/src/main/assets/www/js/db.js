/* FieldTrace IndexedDB — multi-year, multi-project archive */
const DB_NAME = 'fieldtrace-phd';
const DB_VER = 2;

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = () => {
      const db = req.result;
      const tx = req.transaction;
      if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('trips')) {
        const s = db.createObjectStore('trips', { keyPath: 'id' });
        s.createIndex('projectId', 'projectId', { unique: false });
      } else if (tx) {
        const s = tx.objectStore('trips');
        if (s && !s.indexNames.contains('projectId')) s.createIndex('projectId', 'projectId', { unique: false });
      }
      if (!db.objectStoreNames.contains('points')) {
        const s = db.createObjectStore('points', { keyPath: 'id' });
        s.createIndex('tripId', 'tripId', { unique: false });
        s.createIndex('projectId', 'projectId', { unique: false });
      } else if (tx) {
        const s = tx.objectStore('points');
        if (s && !s.indexNames.contains('projectId')) s.createIndex('projectId', 'projectId', { unique: false });
      }
      if (!db.objectStoreNames.contains('stops')) {
        const s = db.createObjectStore('stops', { keyPath: 'id' });
        s.createIndex('tripId', 'tripId', { unique: false });
        s.createIndex('projectId', 'projectId', { unique: false });
      } else if (tx) {
        const s = tx.objectStore('stops');
        if (s && !s.indexNames.contains('projectId')) s.createIndex('projectId', 'projectId', { unique: false });
      }
      if (!db.objectStoreNames.contains('photos')) db.createObjectStore('photos', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('aborted'));
  });
}

const FTDB = {
  _db: null,
  async init() {
    this._db = await openDb();
    return this._db;
  },
  async put(store, value) {
    const tx = this._db.transaction(store, 'readwrite');
    tx.objectStore(store).put(value);
    await txDone(tx);
    return value;
  },
  async get(store, id) {
    return new Promise((resolve, reject) => {
      const tx = this._db.transaction(store, 'readonly');
      const r = tx.objectStore(store).get(id);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  },
  async all(store) {
    return new Promise((resolve, reject) => {
      const tx = this._db.transaction(store, 'readonly');
      const r = tx.objectStore(store).getAll();
      r.onsuccess = () => resolve(r.result || []);
      r.onerror = () => reject(r.error);
    });
  },
  async byIndex(store, index, value) {
    return new Promise((resolve, reject) => {
      const tx = this._db.transaction(store, 'readonly');
      const r = tx.objectStore(store).index(index).getAll(value);
      r.onsuccess = () => resolve(r.result || []);
      r.onerror = () => reject(r.error);
    });
  },
  async del(store, id) {
    const tx = this._db.transaction(store, 'readwrite');
    tx.objectStore(store).delete(id);
    await txDone(tx);
  },
  async getMeta(key) {
    const row = await this.get('meta', key);
    return row ? row.value : undefined;
  },
  async setMeta(key, value) {
    return this.put('meta', { key, value });
  },
  uid(prefix) {
    return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }
};

window.FTDB = FTDB;
